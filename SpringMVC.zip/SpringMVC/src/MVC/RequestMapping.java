package MVC;

public @interface RequestMapping {

	String value() default "";

}
