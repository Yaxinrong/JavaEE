package MVC;

import java.util.Map;
import java.util.HashMap;


public class ModelAndView {

	private String stringName;
	private Map<String,String> map =new HashMap<>();
	private Map<String,String> response=new HashMap<>();
	public void setViewName(String stringName) {
		this.stringName=stringName;
		// TODO Auto-generated method stub
		
	}
	public String getStringname(){
		return stringName;
	}

	public String getMap(String stringName) {
		return this.map.get(stringName);
		// TODO Auto-generated method stub
	}

	public void addObject(String key, String value) {
		this.response.put(key, value);
		// TODO Auto-generated method stub
		
	}

}
