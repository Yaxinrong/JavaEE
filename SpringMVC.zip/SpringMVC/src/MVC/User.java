package MVC;

public class User {
	private String name;
	private String pas;
	
	public User(String name,String pas){
		super();
		this.name=name;
		this.pas=pas;
	}
	
	public String getUsername(){
		return this.name;
	}
	
	public String getPassword(){
		return this.pas;
	}
	public void setUsername(String name){
		this.name=name;
	}
	
	public void setPassword(String pas){
		this.pas=pas;
	}

}
