package MVC;

public @interface Controller {

}
