package MVC;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DispathcherServlet extends HttpServlet{
	
	 /**
	 * 
	 */
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,	IOException{

		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		String password = request.getParameter("pas");
		String message = "";
		
			message="can't leave it blank";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index").forward(request, response);
	}

	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,	IOException{
		doPost(request, response);
		}
}
