package assignment;

public interface BeforeAdvice extends Advice {
}
