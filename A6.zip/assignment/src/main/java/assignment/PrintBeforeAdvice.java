package assignment;

public class PrintBeforeAdvice {

	public PrintBeforeAdvice() {
		System.out.println("hello javaee zhujiao!");
		System.out.println("this my aop application");
		// TODO Auto-generated constructor stub
	}

}
