package assignment;

public interface FooInterface {
	 public void printFoo();
	 public void dummyFoo();
}
