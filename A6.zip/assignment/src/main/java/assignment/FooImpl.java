package assignment;

public class FooImpl implements FooInterface {

	public void printFoo() {
		System.out.println("In FooImpl.printFoo");
		// TODO Auto-generated method stub
		
	}

	public void dummyFoo() {
		 System.out.println("In FooImpl.dummyFoo");
		// TODO Auto-generated method stub
		
	}

}
