package assignment;

public interface Advice {

}
